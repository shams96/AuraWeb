'use client'

import { useEffect, useRef, useState, useCallback } from 'react'
import Link from 'next/link'
import Image from 'next/image'

/* ═══════════════════════════════════════════════════════════════════════
   GRAND DOOR — LIRI ROMA
   The visitor does not open a website. They arrive at a house.

   A Red Ochre (#9B4722) door stands closed. It opens on scroll, click,
   or pointer approach — revealing the collection, shelved, in warm light.

   Accessibility & SEO contract:
   · The H1 and all copy exist in the DOM at all times (never JS-injected).
   · prefers-reduced-motion → doors are open on load. No animation. Ever.
   · Keyboard: the door is a real button, focusable, Enter/Space opens.
   · Mobile: no pointer-proximity; tap or scroll opens. Shorter travel.
   ═══════════════════════════════════════════════════════════════════════ */

const SHELF = [
  { name: 'Cellular Cleanser™',    role: 'Cleanse',              img: '/images/products/isola_collection.png' },
  { name: 'Liri Essence™',          role: 'The Signature Serum',  img: '/images/products/isola_serum.png', hero: true },
  { name: 'Terra Radiance Crème™',  role: 'Day',                  img: '/images/products/isola_collection.png' },
  { name: 'Liri Eye Concentrate™',  role: 'Eye',                  img: '/images/products/isola_serum.png' },
]

export function GrandDoor() {
  const [open, setOpen] = useState(false)
  const [reduced, setReduced] = useState(false)
  const sectionRef = useRef<HTMLElement | null>(null)

  /* Reduced motion → open immediately, permanently. */
  useEffect(() => {
    const mq = window.matchMedia('(prefers-reduced-motion: reduce)')
    if (mq.matches) { setReduced(true); setOpen(true) }
    const onChange = (e: MediaQueryListEvent) => {
      if (e.matches) { setReduced(true); setOpen(true) }
    }
    mq.addEventListener('change', onChange)
    return () => mq.removeEventListener('change', onChange)
  }, [])

  const openDoor = useCallback(() => setOpen(true), [])

  /* Scroll opens the door. Passive listener, unbinds once open. */
  useEffect(() => {
    if (open || reduced) return
    const onScroll = () => { if (window.scrollY > 40) setOpen(true) }
    window.addEventListener('scroll', onScroll, { passive: true })
    return () => window.removeEventListener('scroll', onScroll)
  }, [open, reduced])

  /* Pointer approach opens the door — desktop only, fine pointers only. */
  useEffect(() => {
    if (open || reduced) return
    if (!window.matchMedia('(pointer: fine)').matches) return
    const onMove = (e: PointerEvent) => {
      const el = sectionRef.current
      if (!el) return
      const r = el.getBoundingClientRect()
      const cx = r.left + r.width / 2
      const cy = r.top + r.height / 2
      const dist = Math.hypot(e.clientX - cx, e.clientY - cy)
      if (dist < Math.min(r.width, r.height) * 0.28) setOpen(true)
    }
    window.addEventListener('pointermove', onMove, { passive: true })
    return () => window.removeEventListener('pointermove', onMove)
  }, [open, reduced])

  return (
    <section
      ref={sectionRef}
      aria-label="LIRI ROMA — enter the house"
      style={{
        position: 'relative',
        minHeight: '100svh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        overflow: 'hidden',
        background: 'var(--iv-cloud-dancer, #F0F2EB)',
      }}
    >
      {/* ── THE INTERIOR — always in the DOM. SEO + a11y safe. ───────── */}
      <div
        style={{
          position: 'absolute',
          inset: 0,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          justifyContent: 'center',
          padding: '6vh 5vw',
          textAlign: 'center',
          opacity: open ? 1 : 0,
          transform: open ? 'none' : 'translateY(12px)',
          transition: reduced ? 'none' : 'opacity 1600ms cubic-bezier(.16,1,.3,1) 700ms, transform 1600ms cubic-bezier(.16,1,.3,1) 700ms',
        }}
      >
        <p
          style={{
            fontFamily: 'var(--iv-font-body)',
            fontSize: 'clamp(9px, 1vw, 11px)',
            letterSpacing: '0.42em',
            textTransform: 'uppercase',
            color: 'var(--iv-ochre, #9B4722)',
            marginBottom: '1.6rem',
          }}
        >
          Isola del Liri · Lazio · Italia
        </p>

        <h1
          style={{
            fontFamily: 'var(--iv-font-serif)',
            fontWeight: 300,
            fontSize: 'clamp(2.1rem, 5.4vw, 4.5rem)',
            lineHeight: 1.06,
            color: 'var(--iv-charcoal, #1A1614)',
            margin: 0,
            maxWidth: '18ch',
          }}
        >
          Your skin is a story
          <br />
          <em style={{ fontStyle: 'italic', color: 'var(--iv-ochre, #9B4722)' }}>worth honoring</em>
        </h1>

        <p
          style={{
            fontFamily: 'var(--iv-font-body)',
            fontSize: 'clamp(0.9rem, 1.15vw, 1.0rem)',
            lineHeight: 1.75,
            color: 'var(--iv-text, #3D2B20)',
            maxWidth: '46ch',
            margin: '1.8rem 0 0',
          }}
        >
          A house built where the waters fall. Matched to your biology,
          proven on your own skin within forty-eight hours.
        </p>

        {/* ── THE SHELF ─────────────────────────────────────────────── */}
        <ul
          style={{
            listStyle: 'none',
            display: 'flex',
            alignItems: 'flex-end',
            justifyContent: 'center',
            gap: 'clamp(1rem, 3.2vw, 3.4rem)',
            margin: 'clamp(2.4rem, 5vh, 4rem) 0 0',
            padding: 0,
            flexWrap: 'wrap',
          }}
        >
          {SHELF.map((p, i) => (
            <li
              key={p.name}
              style={{
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                opacity: open ? 1 : 0,
                transform: open ? 'none' : 'translateY(22px)',
                transition: reduced
                  ? 'none'
                  : `opacity 1100ms cubic-bezier(.16,1,.3,1) ${1000 + i * 130}ms, transform 1100ms cubic-bezier(.16,1,.3,1) ${1000 + i * 130}ms`,
              }}
            >
              <div
                style={{
                  position: 'relative',
                  width: p.hero ? 'clamp(74px, 9vw, 116px)' : 'clamp(58px, 7vw, 92px)',
                  height: p.hero ? 'clamp(112px, 13.5vw, 176px)' : 'clamp(88px, 10.5vw, 140px)',
                }}
              >
                <Image
                  src={p.img}
                  alt={`${p.name} — ${p.role}`}
                  fill
                  sizes="(max-width: 768px) 25vw, 12vw"
                  style={{ objectFit: 'contain' }}
                  priority={i === 1}
                />
              </div>

              {/* the shelf line */}
              <span
                aria-hidden
                style={{
                  display: 'block',
                  width: 'clamp(66px, 8.5vw, 112px)',
                  height: 1,
                  background: 'var(--iv-champagne-gold, #D6C5A0)',
                  marginTop: '0.7rem',
                }}
              />

              <span
                style={{
                  fontFamily: 'var(--iv-font-serif)',
                  fontSize: 'clamp(0.72rem, 0.95vw, 0.9rem)',
                  color: 'var(--iv-charcoal, #1A1614)',
                  marginTop: '0.85rem',
                }}
              >
                {p.name}
              </span>
              <span
                style={{
                  fontFamily: 'var(--iv-font-body)',
                  fontSize: 'clamp(8px, 0.72vw, 10px)',
                  letterSpacing: '0.22em',
                  textTransform: 'uppercase',
                  color: 'var(--iv-text-muted, #5C4438)',
                  marginTop: '0.3rem',
                }}
              >
                {p.role}
              </span>
            </li>
          ))}
        </ul>

        {/* ── ONE PRIMARY, ONE SECONDARY ────────────────────────────── */}
        <div
          style={{
            display: 'flex',
            alignItems: 'center',
            gap: '2rem',
            flexWrap: 'wrap',
            justifyContent: 'center',
            marginTop: 'clamp(2.2rem, 4.5vh, 3.4rem)',
            opacity: open ? 1 : 0,
            transition: reduced ? 'none' : 'opacity 1000ms ease 1700ms',
          }}
        >
          <Link
            href="/assessment"
            style={{
              fontFamily: 'var(--iv-font-body)',
              fontSize: '0.78rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: 'var(--iv-cloud-dancer, #F0F2EB)',
              background: 'var(--iv-ochre, #9B4722)',
              padding: '1.05rem 2.6rem',
              textDecoration: 'none',
              transition: 'background 420ms ease',
            }}
          >
            Begin your ritual
          </Link>

          <Link
            href="/shop"
            style={{
              fontFamily: 'var(--iv-font-body)',
              fontSize: '0.78rem',
              letterSpacing: '0.2em',
              textTransform: 'uppercase',
              color: 'var(--iv-text, #3D2B20)',
              textDecoration: 'none',
              borderBottom: '1px solid var(--iv-champagne-gold, #D6C5A0)',
              paddingBottom: '3px',
            }}
          >
            View the collection
          </Link>
        </div>
      </div>

      {/* ── THE DOORS ─────────────────────────────────────────────────
          Two Red Ochre leaves. Not rendered at all under reduced motion. */}
      {!reduced && (
        <>
          {(['left', 'right'] as const).map((side) => (
            <div
              key={side}
              aria-hidden="true"
              style={{
                position: 'absolute',
                top: 0,
                bottom: 0,
                [side]: 0,
                width: '50.5%',
                background: 'var(--iv-ochre, #9B4722)',
                transform: open
                  ? `translateX(${side === 'left' ? '-101%' : '101%'})`
                  : 'translateX(0)',
                transition: 'transform 1900ms cubic-bezier(.62,.02,.16,1)',
                willChange: 'transform',
                pointerEvents: open ? 'none' : 'auto',
                /* the inner edge catches light, like a real leaf */
                boxShadow:
                  side === 'left'
                    ? 'inset -1px 0 0 rgba(214,197,160,.5)'
                    : 'inset 1px 0 0 rgba(214,197,160,.5)',
              }}
            >
              {/* a single recessed panel — restraint, not ornament */}
              <span
                aria-hidden
                style={{
                  position: 'absolute',
                  top: '11%',
                  bottom: '11%',
                  [side === 'left' ? 'left' : 'right']: '13%',
                  [side === 'left' ? 'right' : 'left']: '8%',
                  border: '1px solid rgba(214,197,160,.24)',
                }}
              />
            </div>
          ))}

          {/* The mark on the meeting rail — and the way in. */}
          <button
            type="button"
            onClick={openDoor}
            onFocus={openDoor}
            aria-label="Enter LIRI ROMA"
            aria-expanded={open}
            style={{
              position: 'absolute',
              top: '50%',
              left: '50%',
              transform: 'translate(-50%, -50%)',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              gap: '1.6rem',
              background: 'transparent',
              border: 0,
              cursor: open ? 'default' : 'pointer',
              opacity: open ? 0 : 1,
              transition: 'opacity 620ms ease',
              pointerEvents: open ? 'none' : 'auto',
              padding: '2rem',
            }}
          >
            {/* LR — the house mark */}
            <span
              style={{
                fontFamily: 'var(--iv-font-serif)',
                fontSize: 'clamp(2.6rem, 5vw, 4rem)',
                fontWeight: 300,
                letterSpacing: '0.04em',
                color: 'var(--iv-champagne-gold, #D6C5A0)',
                lineHeight: 1,
              }}
            >
              LR
            </span>
            <span
              style={{
                fontFamily: 'var(--iv-font-body)',
                fontSize: 'clamp(8px, 0.8vw, 10px)',
                letterSpacing: '0.44em',
                textTransform: 'uppercase',
                color: 'rgba(214,197,160,.72)',
              }}
            >
              Enter
            </span>
          </button>
        </>
      )}
    </section>
  )
}
