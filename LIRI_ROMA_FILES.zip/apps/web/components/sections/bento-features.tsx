'use client'

import Link from 'next/link'
import { ArrowRight } from 'lucide-react'

const GOLD = 'rgba(155, 71, 34,'

export function BentoFeatures() {
  return (
    <section className="py-24 bg-iv-black">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 max-w-7xl">

        {/* Section label */}
        <div className="text-center mb-14 iv-scroll-reveal">
          <div
            className="inline-block rounded-full px-6 py-2 text-[11px] font-black uppercase tracking-[0.3em] mb-5"
            style={{ color: 'var(--iv-gold)', border: `1px solid ${GOLD}0.20)`, background: `${GOLD}0.05)` }}
          >
            La Bella Figura
          </div>
          <h2 className="iv-type-h2 font-bold text-iv-white tracking-tighter">
            A Ritual, Not a <span className="italic text-iv-gold">Routine</span>
          </h2>
        </div>

        {/* Bento grid */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">

          {/* ── [A] Clinical evidence — full width ─────────────── */}
          <div
            className="iv-scroll-card md:col-span-12 rounded-3xl p-8 md:p-10 flex flex-col justify-between relative overflow-hidden"
            style={{
              background: `linear-gradient(135deg, var(--iv-deep-green) 0%, rgba(0, 75, 55,0.40) 100%)`,
              border: `1px solid ${GOLD}0.16)`,
              minHeight: 260,
            }}
          >
            <span
              className="absolute right-6 md:right-12 bottom-0 font-black leading-none select-none pointer-events-none"
              style={{ fontSize: 'clamp(5rem, 18vw, 13rem)', color: `${GOLD}0.06)`, fontFamily: 'var(--iv-font-serif)' }}
              aria-hidden
            >4</span>

            <div className="relative z-10">
              <p className="text-[11px] font-black uppercase tracking-[0.3em] mb-4" style={{ color: 'var(--iv-gold)' }}>
                Clinical Evidence
              </p>
              <h3 className="iv-type-h3 font-bold text-iv-white leading-tight mb-3" style={{ fontFamily: 'var(--iv-font-serif)' }}>
                Six research-confirmed actives. Formulated at the concentrations the science used.
              </h3>
              <p className="text-sm text-iv-cream/65 font-light max-w-lg leading-relaxed">
                Every active in every LIRI ROMA formulation was independently validated before inclusion. We do not introduce an ingredient until the evidence exists — then we formulate to it, not around it.
              </p>
            </div>

            <div className="flex flex-wrap gap-3 mt-8 relative z-10">
              {['J Cosmet Dermatol 2025', 'Aesthetic Surgery Journal 2024', 'Eurofins Dermatest', 'Dermscan Group'].map(t => (
                <span
                  key={t}
                  className="text-[11px] font-black uppercase tracking-widest px-4 py-2 rounded-full"
                  style={{ background: `${GOLD}0.10)`, color: 'var(--iv-gold)', border: `1px solid ${GOLD}0.18)` }}
                >
                  {t}
                </span>
              ))}
            </div>
          </div>

          {/* ── [B] 4-Tier system — 7 cols on md ──────────────── */}
          <div
            className="iv-scroll-card md:col-span-7 rounded-3xl p-8 flex flex-col justify-between"
            style={{
              background: 'var(--iv-deep-green)',
              border: `1px solid ${GOLD}0.14)`,
              minHeight: 240,
            }}
          >
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] mb-3" style={{ color: 'var(--iv-gold)' }}>The Science of Skin Vitality</p>
              <h3 className="iv-type-h3 font-bold text-iv-white mb-3" style={{ fontFamily: 'var(--iv-font-serif)' }}>
                Four domains. One system. Matched to your biology — not your birthdate.
              </h3>
              <p className="text-sm text-iv-cream/65 font-light leading-relaxed">
                Preservation · Refinement · Regeneration · Longevity. Four protocols built around the four domains of adaptive skin science.
              </p>
            </div>
            <div className="flex gap-2 mt-6">
              {[
                { label: 'Preservation', sub: 'Renewal & resilience' },
                { label: 'Refinement', sub: 'Barrier & clarity' },
                { label: 'Regeneration', sub: 'Protection & repair' },
                { label: 'Longevity', sub: 'Structure & vitality' },
              ].map(({ label, sub }) => (
                <div key={label} className="flex-1 rounded-xl p-3 text-center" style={{ background: `${GOLD}0.08)`, border: `1px solid ${GOLD}0.14)` }}>
                  <div className="text-[10px] font-black text-iv-gold uppercase tracking-widest">{label}</div>
                  <div className="text-[9px] text-iv-cream/65 mt-1 font-light">{sub}</div>
                </div>
              ))}
            </div>
          </div>

          {/* ── [C] Consultation CTA — 5 cols on md ───────────── */}
          <div
            className="iv-scroll-card md:col-span-5 rounded-3xl p-8 flex flex-col justify-between"
            style={{ background: 'var(--iv-gold)', minHeight: 240 }}
          >
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] mb-3 text-white/60">Begin Here</p>
              <h3 className="iv-type-h3 font-bold text-white mb-2" style={{ fontFamily: 'var(--iv-font-serif)' }}>
                Discover your ritual in 2 minutes
              </h3>
              <p className="text-sm text-white/70 font-light leading-relaxed">
                8 questions. Your personal formulation matched to your skin's biology — with a complete morning and evening ritual.
              </p>
            </div>
            <Link
              href="#skin-scan"
              className="inline-flex items-center gap-2 mt-6 text-[11px] font-black uppercase tracking-[0.2em] text-white group"
              onClick={e => {
                e.preventDefault()
                document.getElementById('skin-scan')?.scrollIntoView({ behavior: 'smooth' })
              }}
            >
              Begin your ritual <ArrowRight size={14} className="group-hover:translate-x-1 transition-transform" />
            </Link>
          </div>

          {/* ── [D] Italian lab — 5 cols on md ─────────────────── */}
          <div
            className="iv-scroll-card md:col-span-5 rounded-3xl p-8 flex flex-col justify-between"
            style={{
              background: `linear-gradient(140deg, ${GOLD}0.08) 0%, var(--iv-deep-green) 100%)`,
              border: `1px solid ${GOLD}0.14)`,
              minHeight: 220,
            }}
          >
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.3em] mb-3" style={{ color: 'var(--iv-gold)' }}>Manufacturing</p>
              <h3 className="text-lg font-bold text-iv-white mb-2" style={{ fontFamily: 'var(--iv-font-serif)' }}>
                Natural You Srl — Isola del Liri
              </h3>
              <p className="text-sm text-iv-cream/65 font-light leading-relaxed">
                EU GMP certified. ICH Q1A 24-month stability. Every active at declared pharmaceutical-grade concentration.
              </p>
            </div>
            <div className="flex flex-wrap gap-3 mt-5">
              {['EU GMP', 'ISO 17025', '99.8% Purity', 'Vegan'].map(b => (
                <span key={b} className="text-[11px] font-black uppercase tracking-widest text-iv-cream/65 border-b pb-0.5" style={{ borderColor: `${GOLD}0.25)` }}>{b}</span>
              ))}
            </div>
          </div>

          {/* ── [E] Three stat cells — 7 cols split 3 ways on md ─ */}
          <div className="md:col-span-7 grid grid-cols-1 sm:grid-cols-3 gap-4">
            {[
              { value: '97%', label: 'Smoother Skin', sub: 'Week 4 · n=2,450' },
              { value: '18', label: 'Formulations', sub: 'All protocols' },
              { value: '4.8★', label: 'Avg Rating', sub: '2,450+ reviews' },
            ].map((stat, i) => (
              <div
                key={stat.value}
                className="iv-scroll-stat rounded-2xl p-6 flex flex-col justify-center text-center"
                style={{
                  background: 'var(--iv-deep-green)',
                  border: `1px solid ${GOLD}0.12)`,
                  animationDelay: `${i * 0.08}s`,
                }}
              >
                <div className="font-black text-iv-gold mb-1" style={{ fontSize: 'clamp(1.75rem, 4vw, 2.5rem)', fontFamily: 'var(--iv-font-serif)' }}>
                  {stat.value}
                </div>
                <div className="text-[11px] font-bold text-iv-white uppercase tracking-widest mb-1">{stat.label}</div>
                <div className="text-[11px] text-iv-cream/65 font-light">{stat.sub}</div>
              </div>
            ))}
          </div>

        </div>
      </div>
    </section>
  )
}
