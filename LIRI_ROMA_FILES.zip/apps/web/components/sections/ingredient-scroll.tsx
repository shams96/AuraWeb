'use client'

import { useRef } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'

interface IngredientCard {
  name: string
  concentration: string
  focus: string
  claim: string
  trialRef: string
  icon: string
  color: string
}

const INGREDIENTS: IngredientCard[] = [
  {
    name: 'Cellular Renewal Complex',
    concentration: '0.30%',
    focus: 'Cellular Longevity',
    claim: 'Formulated to support the skin\'s own renewal pathways',
    trialRef: 'Zonari et al. · J Cosmet Dermatol 2025 · RCT · n=60 · 12 wks',
    icon: '⬡',
    color: 'rgba(155, 71, 34,0.12)',
  },
  {
    name: 'DWAT Restoration Complex',
    concentration: '0.75%',
    focus: 'Volume Restoration',
    claim: 'Targets dermal adipose depletion — the documented mechanism of facial volume loss',
    trialRef: 'Kruglikov & Scherer · Aging 2016 · Peer-reviewed',
    icon: '◈',
    color: 'rgba(0, 75, 55,0.12)',
  },
  {
    name: 'metabolic change Protective Complex',
    concentration: '1.25%',
    focus: 'Deflation Prevention',
    claim: 'Addresses documented facial volume loss in metabolic change',
    trialRef: 'Ridha et al. · Aesthetic Surgery Journal 2024 · Peer-reviewed',
    icon: '◉',
    color: 'rgba(12, 45, 56,0.12)',
  },
  {
    name: 'L-Ornithine',
    concentration: '1.50%',
    focus: 'Wrinkle Depth',
    claim: 'Increases collagen-constituting amino acids and polyamines in skin',
    trialRef: 'Kitakaze et al. · BBRC 2019 · Peer-reviewed',
    icon: '◎',
    color: 'rgba(155, 71, 34,0.08)',
  },
  {
    name: 'Bifida Ferment Lysate',
    concentration: '0.50%',
    focus: 'Microbiome Support',
    claim: 'Formulated with microbiome-supporting postbiotic · pH-optimised',
    trialRef: 'Microbiome-conscious formulation · barrier-supportive pH',
    icon: '⬡',
    color: 'rgba(0, 75, 55,0.08)',
  },
  {
    name: 'Ectoin Environmental Shield',
    concentration: '1.00%',
    focus: 'Pollution Defence',
    claim: '18% TEWL reduction · 35% hydration increase vs control',
    trialRef: 'Dermscan Group, Lyon & Milan · Multi-centre · 4 wks · n=96',
    icon: '◈',
    color: 'rgba(12, 45, 56,0.10)',
  },
]

export function IngredientScroll() {
  const railRef = useRef<HTMLDivElement>(null)

  const scroll = (dir: 'left' | 'right') => {
    if (!railRef.current) return
    const card = railRef.current.querySelector('.iv-hscroll-item') as HTMLElement
    const step = card ? card.offsetWidth + 24 : 340
    railRef.current.scrollBy({ left: dir === 'right' ? step : -step, behavior: 'smooth' })
  }

  return (
    <section className="py-24 bg-iv-black overflow-hidden">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">

        {/* Header row */}
        <div className="flex items-end justify-between mb-12 gap-6 flex-wrap">
          <div className="iv-scroll-reveal">
            <div
              className="inline-block rounded-full px-6 py-2 text-[11px] font-black uppercase tracking-[0.3em] mb-4"
              style={{ color: 'var(--iv-gold)', border: '1px solid rgba(155, 71, 34,0.20)', background: 'rgba(155, 71, 34,0.05)' }}
            >
              The Breakthrough 6
            </div>
            <h2 className="iv-type-h2 font-bold text-iv-white tracking-tighter">
              Proprietary <span className="italic text-iv-gold">Actives</span>
            </h2>
            <p className="text-iv-cream/65 mt-3 font-light max-w-md leading-relaxed">
              Six research-confirmed actives. Every concentration matched to the independent study that proved it. Swipe to explore.
            </p>
          </div>

          {/* Arrow controls — desktop */}
          <div className="hidden md:flex gap-3 flex-shrink-0">
            <button
              onClick={() => scroll('left')}
              aria-label="Scroll left"
              className="w-12 h-12 rounded-full flex items-center justify-center border transition-all duration-200"
              style={{ border: '1px solid rgba(155, 71, 34,0.22)', color: 'var(--iv-gold)' }}
              onMouseEnter={e => {
                ;(e.currentTarget as HTMLElement).style.background = 'var(--iv-gold)'
                ;(e.currentTarget as HTMLElement).style.color = '#fff'
              }}
              onMouseLeave={e => {
                ;(e.currentTarget as HTMLElement).style.background = 'transparent'
                ;(e.currentTarget as HTMLElement).style.color = 'var(--iv-gold)'
              }}
            >
              <ChevronLeft size={20} />
            </button>
            <button
              onClick={() => scroll('right')}
              aria-label="Scroll right"
              className="w-12 h-12 rounded-full flex items-center justify-center transition-all duration-200"
              style={{ background: 'var(--iv-gold)', color: '#fff' }}
              onMouseEnter={e => (e.currentTarget as HTMLElement).style.background = 'var(--iv-gold-light)'}
              onMouseLeave={e => (e.currentTarget as HTMLElement).style.background = 'var(--iv-gold)'}
            >
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        {/* Horizontal scroll rail */}
        <div ref={railRef} className="iv-hscroll">
          {INGREDIENTS.map((ing, i) => (
            <div
              key={ing.name}
              className="iv-hscroll-item iv-scroll-card"
              style={{
                width: 'clamp(260px, 32vw, 340px)',
                animationDelay: `${i * 0.06}s`,
              }}
            >
              <div
                className="h-full rounded-2xl p-8 flex flex-col gap-6 transition-all duration-300 group"
                style={{
                  background: `linear-gradient(140deg, var(--iv-deep-green) 0%, ${ing.color} 100%)`,
                  border: '1px solid rgba(155, 71, 34,0.14)',
                  minHeight: 280,
                }}
                onMouseEnter={e => (e.currentTarget as HTMLElement).style.borderColor = 'rgba(155, 71, 34,0.35)'}
                onMouseLeave={e => (e.currentTarget as HTMLElement).style.borderColor = 'rgba(155, 71, 34,0.14)'}
              >
                {/* Top row */}
                <div className="flex items-start justify-between">
                  <span
                    className="w-11 h-11 rounded-full flex items-center justify-center text-xl flex-shrink-0"
                    style={{ background: 'rgba(155, 71, 34,0.09)', border: '1px solid rgba(155, 71, 34,0.18)' }}
                  >
                    {ing.icon}
                  </span>
                  <span
                    className="text-[11px] font-black uppercase tracking-widest px-3 py-1 rounded-full"
                    style={{ background: 'rgba(155, 71, 34,0.10)', color: 'var(--iv-gold)', border: '1px solid rgba(155, 71, 34,0.18)' }}
                  >
                    {ing.concentration}
                  </span>
                </div>

                {/* Name + focus */}
                <div>
                  <p className="text-[11px] font-black uppercase tracking-[0.22em] mb-2" style={{ color: 'var(--iv-gold)' }}>
                    {ing.focus}
                  </p>
                  <h3 className="text-base font-bold text-iv-white leading-snug" style={{ fontFamily: 'var(--iv-font-serif)' }}>
                    {ing.name}
                  </h3>
                </div>

                {/* Divider */}
                <div style={{ height: 1, background: 'rgba(155, 71, 34,0.12)' }} />

                {/* Clinical claim */}
                <div className="mt-auto">
                  <p className="text-sm text-iv-gold font-semibold leading-snug mb-2">{ing.claim}</p>
                  <p className="text-[11px] text-iv-cream/65 font-light uppercase tracking-[0.15em]">{ing.trialRef}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Mobile scroll hint */}
        <p className="md:hidden text-center text-[11px] text-iv-cream/65 uppercase tracking-widest mt-6 font-light">
          Swipe to explore all 6 actives
        </p>
      </div>
    </section>
  )
}
